﻿using System;
namespace ProjetRENOIR
{
	public class Camion : Vehicule
	{
		int volume;
		string matieres;

		public Camion(string immat, int volume, string matieres) : base(immat)
		{
			this.volume = volume;
			this.matieres = matieres;
		}

        public override string ToString()
        {
            return base.ToString() + " Volume : " + volume + " Matieres transportées : " + matieres;
        }
    }
}

