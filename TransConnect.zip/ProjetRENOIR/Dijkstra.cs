﻿using System;
namespace ProjetRENOIR
{
	public class Dijkstra
    {
        Dictionary<Noeud, int> Distances;
        Dictionary<Noeud, Noeud> Routes;
        Graph graph;
        List<Noeud> AllNoeuds;

        public Dijkstra(Graph g)
        {
            this.graph = g;
            this.AllNoeuds = g.GetNoeuds();
            Distances = InitDistances();
            Routes = SetRoutes();
        }

        /// <summary>Initialise les distances des nœuds dans le graphe avec une valeur infinie.</summary>
        /// <returns>Un dictionnaire initialisé avec chaque nœud du graphe ayant une distance infinie.</returns>
        private Dictionary<Noeud, int> InitDistances()
        {
            Dictionary<Noeud, int> Distances = new Dictionary<Noeud, int>();

            foreach (Noeud n in graph.GetNoeuds())
            {
                Distances.Add(n, int.MaxValue);
            }
            return Distances;
        }

        /// <summary>Initialise les routes pour chaque nœud dans le graphe avec une valeur null.</summary>
        /// <returns>Un dictionnaire initialisé avec chaque nœud du graphe ayant une route nulle.</returns>
        private Dictionary<Noeud, Noeud> SetRoutes()
        {
            Dictionary<Noeud, Noeud> Routes = new Dictionary<Noeud, Noeud>();

            foreach (Noeud n in graph.GetNoeuds())
            {
                Routes.Add(n, null);
            }
            return Routes;
        }

        /// <summary>Trouve le nœud le plus proche parmi une collection de nœuds.</summary>
        /// <returns>Le nœud avec la plus petite distance.</returns>
        private Noeud NoeudPlusProche()
        {
            Noeud noeudPlusProche = AllNoeuds[0];

            foreach (var n in AllNoeuds)
            {
                if (Distances[n] < Distances[noeudPlusProche])
                    noeudPlusProche = n;
            }

            return noeudPlusProche;
        }

        /// <summary>Analyse les voisins d'un nœud pour mettre à jour les distances et les routes si un chemin plus court est découvert.</summary>
        /// <param name="n">Le nœud dont les voisins doivent être analysés.</param>
        private void AnalyserVoisins(Noeud n)
        {
            foreach (var voisin in n.Voisins())
            {
                Noeud noeudVoisin = voisin.Key;
                int distanceVersVoisin = voisin.Value;
                int nouvelleDistance = Distances[n] + distanceVersVoisin;

                if (nouvelleDistance < Distances[noeudVoisin])
                {
                    Distances[noeudVoisin] = nouvelleDistance;
                    Routes[noeudVoisin] = n;
                }
            }
        }

        /// <summary>Calcule le chemin le plus court du nœud source au nœud destination en utilisant l'algorithme de Dijkstra.</summary>
        /// <param name="depart">La ville de départ de la livraison</param>
        /// <param name="arrivee">La ville d'arrivée de la livraison</param>
        public int Calculate(Noeud depart, Noeud arrivee)
        {
            Distances[depart] = 0;// Initialise la distance du nœud de départ à 0
            string route = "";// Chemin plus court sous forme de chaîne
            Noeud noeudFinal = arrivee;// Conserver une référence au nœud final pour retourner la distance finale

            while (AllNoeuds.ToList().Count != 0)// Continuer tant qu'il reste des nœuds non visités
            {
                Noeud n = NoeudPlusProche();// Trouver le nœud non visité le plus proche
                AnalyserVoisins(n);// Mettre à jour les distances pour tous les voisins du nœud sélectionné
                AllNoeuds.Remove(n);// Marquer le nœud comme visité
            }

            while (arrivee != depart)// Construire le chemin en remontant à partir du nœud d'arrivée jusqu'au départ
            {
                route = arrivee.Nom() + " --> " + route;// Ajouter le nom du nœud actuel au début du chemin
                arrivee = Routes[arrivee];// Passer au nœud précédent dans le chemin optimal
            }

            route = depart.Nom() + " --> " + route.TrimEnd(' ', '-', '>');// Ajouter le nœud de départ au début du chemin et supprimer les caractères inutiles
            Console.WriteLine(route);// Afficher le chemin trouvé dans la console
            return Distances[noeudFinal];// Retourner la distance du nœud de départ au nœud d'arrivée
        }
    }
}

