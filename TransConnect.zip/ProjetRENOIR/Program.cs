﻿using System.Xml.Serialization;
using System.IO;
using System.Xml.Linq;
using static System.Net.WebRequestMethods;
using System.Text;

namespace ProjetRENOIR;

class Program
{
    static void Main(string[] args)
    {

        #region Création des employés
        Salarie DUPOND = new Salarie("2904728173", "DUPOND", "Phillipe", new DateTime(1969, 3, 12), "Paris", "dupond@gmail.com", "0606060606", new DateTime(1991, 2, 04), "Directeur Général", 8450);
        Salarie FIESTA = new Salarie("2904248173", "FIESTA", "Anne", new DateTime(1975, 3, 02), "Toulouse", "fiesta@gmail.com", "0606060636", new DateTime(2000, 4, 09), "Directrice Commerciale", 5600);
        Salarie FETARD = new Salarie("2034248173", "FETARD", "Olivier", new DateTime(1966, 3, 03), "Angers", "fetard@gmail.com", "0606340606", new DateTime(1994, 4, 05), "Directeur des opérations", 4300);
        Salarie JOYEUSE = new Salarie("2034098173", "JOYEUSE", "Olivia", new DateTime(1973, 2, 07), "Paris", "joyeuse@gmail.com", "0606340106", new DateTime(2003, 3, 09), "Directrice des RH", 4300);
        Salarie GRIPSOUS = new Salarie("2034098893", "GRIPSOUS", "Louis", new DateTime(1979, 1, 02), "Paris", "gripsous@gmail.com", "0386340106", new DateTime(2001, 3, 02), "Directeur Financier", 4300);
        Salarie FORGE = new Salarie("2034328893", "FORGE", "Nicolas", new DateTime(1990, 1, 08), "Paris", "forge@gmail.com", "0380940106", new DateTime(2002, 2, 03), "Commercial", 2300);
        Salarie FERMI = new Salarie("2234328893", "FERMI", "Louise", new DateTime(1974, 1, 03), "Paris", "fermi@gmail.com", "0390942106", new DateTime(1999, 3, 10), "Commerciale", 2300);
        Salarie ROYAL = new Salarie("2344328893", "ROYAL", "Maxime", new DateTime(2002, 1, 10), "Angers", "royal@gmail.com", "0340092106", new DateTime(2023, 4, 10), "Chef Equipe", 2300);
        Chauffeur ROMU = new Chauffeur("2344028893", "ROMU", "Eliot", new DateTime(1988, 1, 11), "Nimes", "romu@gmail.com", "0349992106", new DateTime(2020, 4, 12), "Chauffeur", 2000, true);
        Chauffeur ROMI = new Chauffeur("2344029993", "ROMI", "Elisa", new DateTime(1989, 2, 11), "Paris", "romi@gmail.com", "0349988106", new DateTime(2013, 4, 03), "Chauffeuse", 2000, true);
        Chauffeur ROMA = new Chauffeur("2344027793", "ROMA", "Leo", new DateTime(2000, 4, 04), "Montpellier", "roma@gmail.com", "0349778106", new DateTime(2008, 4, 02), "Chauffeur", 2000, true);
        Salarie PRINCE = new Salarie("2344033793", "PRINCE", "Lea", new DateTime(2001, 3, 04), "Paris", "prince@gmail.com", "0349767106", new DateTime(2009, 4, 05), "Chef Equipe", 2900);
        Chauffeur ROME = new Chauffeur("2344036693", "ROME", "Tania", new DateTime(1998, 3, 11), "Montpellier", "rome@gmail.com", "0323767106", new DateTime(2019, 4, 03), "Chauffeuse", 2000, true);
        Chauffeur RIMOU = new Chauffeur("2344986693", "RIMOU", "Camille", new DateTime(1997, 5, 11), "Angers", "rimou@gmail.com", "0323767346", new DateTime(2019, 12, 02), "Chauffeuse", 2000, true);
        Salarie COULEUR = new Salarie("2332986693", "COULEUR", "Fleur", new DateTime(1978, 3, 11), "Paris", "couleur@gmail.com", "0323790346", new DateTime(2012, 03, 02), "Formation", 2000);
        Salarie TOUTLEMONDE = new Salarie("2332656690", "TOUTLEMONDE", "Annie", new DateTime(1986, 3, 11), "Paris", "toutlemonde@gmail.com", "0323650346", new DateTime(2004, 08, 02), "Contrats", 2000);
        Salarie PICSOU = new Salarie("2333256690", "PICSOU", "Robert", new DateTime(1990, 4, 09), "Paris", "picsou@gmail.com", "0453650346", new DateTime(2000, 12, 02), "Direction Comptable", 2890);
        Salarie FOURNIER = new Salarie("2433256690", "FOURNIER", "Aline", new DateTime(1987, 4, 10), "Toulouse", "fournier@gmail.com", "0453990346", new DateTime(2003, 11, 02), "Comptable", 2290);
        Salarie GAUTIER = new Salarie("2433746690", "GAUTIER", "Nicole", new DateTime(1986, 5, 02), "Montpellier", "gautier@gmail.com", "0453976346", new DateTime(1998, 12, 02), "Comptable", 2290);
        Salarie GROSSOUS = new Salarie("2433746320", "GROSSOUS", "Enzo", new DateTime(2000, 6, 02), "Angers", "grossous@gmail.com", "0453976646", new DateTime(2018, 10, 02), "Controleur de Gestion", 2100);

        Organigramme TransConnect = new Organigramme(DUPOND);

        List<Chauffeur> AllChauffeurs = new List<Chauffeur>();
        AllChauffeurs.Add(ROMU);
        AllChauffeurs.Add(ROMI);
        AllChauffeurs.Add(ROMA);
        AllChauffeurs.Add(ROME);
        AllChauffeurs.Add(RIMOU);

        #endregion

        #region Création des clients
        List<Client> allClients = new List<Client>();

        List<Commande> CelineHistorique = new List<Commande>();
        Client Celine = new Client("29", "ZENA", "Celine", new DateTime(1970, 2, 11), "Lyon", "zena@gmail.com", "0506810606", CelineHistorique, false);
        allClients.Add(Celine);

        List<Commande> JoseHistorique = new List<Commande>();
        Client Jose = new Client("30", "DACOSTA", "Jose", new DateTime(1990, 6, 7), "Marseille", "dacosta@gmail.com", "0506920676", JoseHistorique, false);
        allClients.Add(Jose);

        List<Commande> PierreHistorique = new List<Commande>();
        Client Pierre = new Client("31", "BLAIN", "Pierre", new DateTime(1993, 10, 7), "Paris", "blain@gmail.com", "0504320676", PierreHistorique, false);
        allClients.Add(Pierre);

        List<Commande> RosaHistorique = new List<Commande>();
        Client Rosa = new Client("2942198123", "MART", "Rosa", new DateTime(1960, 9, 3), "Rouen", "mart@gmail.com", "0526909676", RosaHistorique, false);
        allClients.Add(Rosa);

        List<Commande> JeaneHistorique = new List<Commande>();
        Client Jeane = new Client("2945218123", "MOPS", "Jeane", new DateTime(2000, 7, 7), "Montpellier", "mops@gmail.com", "0506100670", JeaneHistorique, false);
        allClients.Add(Jeane);

        #endregion

        #region Création de la carte de France
        Graph France = new Graph();

        Noeud Strasbourg = new Noeud("Strasbourg");
        Noeud Paris = new Noeud("Paris");
        Noeud Orleans = new Noeud("Orléans");
        Noeud Lyon = new Noeud("Lyon");
        Noeud Toulouse = new Noeud("Toulouse");
        Noeud Bordeaux = new Noeud("Bordeaux");
        Noeud LaRochelle = new Noeud("La Rochelle");
        Noeud Brest = new Noeud("Brest");

        France.Ajouter(Strasbourg);
        France.Ajouter(Paris);
        France.Ajouter(Orleans);
        France.Ajouter(Lyon);
        France.Ajouter(Toulouse);
        France.Ajouter(Bordeaux);
        France.Ajouter(LaRochelle);
        France.Ajouter(Brest);

        Strasbourg.AjouterVoisin(Paris, 492);
        Strasbourg.AjouterVoisin(Orleans, 588);
        Strasbourg.AjouterVoisin(Lyon, 494);

        Paris.AjouterVoisin(Brest, 588);
        Paris.AjouterVoisin(LaRochelle, 469);
        Paris.AjouterVoisin(Bordeaux, 582);
        Paris.AjouterVoisin(Toulouse, 675);

        Orleans.AjouterVoisin(Brest, 588);
        Orleans.AjouterVoisin(LaRochelle, 348);
        Orleans.AjouterVoisin(Bordeaux, 462);
        Orleans.AjouterVoisin(Toulouse, 553);

        Lyon.AjouterVoisin(Brest, 978);
        Lyon.AjouterVoisin(LaRochelle, 699);
        Lyon.AjouterVoisin(Bordeaux, 551);
        Lyon.AjouterVoisin(Toulouse, 534);

        Dijkstra Dijkstra = new Dijkstra(France);
        #endregion

        #region Création des véhicules
        Voiture voitureLivraison = new Voiture("AA-989-GB", 4);
        Camionnette camionnetteLivraison = new Camionnette("ZE-321-HD", "Livraison de colis");
        CamionFrigo frigoLivraison = new CamionFrigo("TE-875-JD", 200, "Carton", 1);
        CamionBenne benneLivraison = new CamionBenne("TP-885-JD", 200, "Pierre", 1, false);
        CamionCiterne citerneLivraison = new CamionCiterne("MP-809-JO", 200, "Liquide", "moyenne");
        #endregion

        List<Commande> allCommandes = new List<Commande>();
        ListeChainee<Commande> FileAttente = new ListeChainee<Commande>();
        Comparer<Commande> comparerDate = (x, y) => x.Date.CompareTo(y.Date);

        bool deco = false;
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine("  _______                   _____                            _   \n |__   __|                 / ____|                          | |  \n    | |_ __ __ _ _ __  ___| |     ___  _ __  _ __   ___  ___| |_ \n    | | '__/ _` | '_ \\/ __| |    / _ \\| '_ \\| '_ \\ / _ \\/ __| __|\n    | | | | (_| | | | \\__ \\ |___| (_) | | | | | | |  __/ (__| |_ \n    |_|_|  \\__,_|_| |_|___/\\_____\\___/|_| |_|_| |_|\\___|\\___|\\__|\n\n");
        Console.ForegroundColor = ConsoleColor.White;

        while (true)
        {
            Console.Write("Identifiant : ");
            string identifiant = Console.ReadLine();
            Console.Write("Mot de passe : ");
            string mdp = Console.ReadLine();
            string mdpHash = Hash.ChiffrerMDP(mdp);
            if (!Hash.LireMotdePasse(identifiant, mdpHash))
            {
                Console.WriteLine("Connexion impossible ! Arrêt du programme...");
                Thread.Sleep(2000);
                Environment.Exit(1);
            }
            deco = false;
            Console.Clear();
            if (identifiant == "admin")
            {
                while (!deco)
                {
                    Console.WriteLine("\nQue souhaitez-vous faire ?\n");
                    Console.WriteLine("1. Gérer vos clients");
                    Console.WriteLine("2. Gérer vos salariés");
                    Console.WriteLine("3. Gérer les commandes");
                    Console.WriteLine("4. Déconnexion");
                    Console.WriteLine("5. Quitter");

                    string c = Console.ReadLine();

                    switch (c)
                    {
                        case "1":
                            //Gestion des Clients
                            Console.WriteLine("Que souhaitez-vous faire ?");
                            Console.WriteLine("1. Ajouter un client");
                            Console.WriteLine("2. Supprimer un client");
                            Console.WriteLine("3. Modifier un client");
                            Console.WriteLine("4. Afficher les clients par ordre alphabétique");
                            Console.WriteLine("5. Afficher les clients par ville");
                            Console.WriteLine("6. Afficher le meilleur client");
                            Console.WriteLine("7. Afficher la liste des commandes pour un client");
                            Console.WriteLine("8. Offrir la livraison à un client");
                            string r = Console.ReadLine();
                            if (r == "1")
                            {
                                //Ajouter un client
                                Console.WriteLine("Quel son numéro de sécurité sociale ?");
                                string numSS = Console.ReadLine();
                                Console.WriteLine("Quel est son nom ?");
                                string nom = Console.ReadLine();
                                Console.WriteLine("Quel est son prenom ?");
                                string prenom = Console.ReadLine();
                                Console.WriteLine("Quel est sa date de naissance ?");
                                string naissance = Console.ReadLine();
                                DateTime dateNaissance = DateTime.MinValue;
                                try
                                {
                                    dateNaissance = DateTime.Parse(naissance);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Erreur de format ! Veuillez entrer la date de naissance au format AAAA-MM-JJ :");
                                    naissance = Console.ReadLine();
                                    dateNaissance = DateTime.Parse(naissance);
                                }
                                Console.WriteLine("Quel est son adresse ?");
                                string adresse = Console.ReadLine();
                                Console.WriteLine("Quel est son email ?");
                                string email = Console.ReadLine();
                                Console.WriteLine("Quel est son telephone ?");
                                string telephone = Console.ReadLine();

                                List<Commande> nouvelleListe = new List<Commande>();

                                Client nouveauClient = new Client(numSS, nom, prenom, dateNaissance, adresse, email, telephone, nouvelleListe, false);

                                allClients.Add(nouveauClient);

                                Console.WriteLine("\nFélicitations, " + prenom + " fait partie de vos clients !\n");
                            }
                            else if (r == "2")
                            {
                                //Supprimer un client
                                Console.WriteLine("Quel son numéro de sécurité sociale ?");
                                string numSS = Console.ReadLine();
                                Client clientASupprimer = allClients.Find(client => client.NumSS == numSS);

                                if (clientASupprimer == null)
                                {
                                    Console.WriteLine("Ce numéro de sécurité sociale n'existe pas");
                                    break;
                                }
                                else
                                {
                                    allClients.RemoveAll(c => c.NumSS.Equals(numSS));
                                    Console.WriteLine("\nClient supprimé avec succès !\n");
                                }
                            }
                            else if (r == "3")
                            {
                                //Modifier un client
                                Console.WriteLine("Quel son numéro de sécurité sociale ?");
                                string numSS = Console.ReadLine();

                                Client clientAModifier = allClients.Find(client => client.NumSS == numSS);
                                if (clientAModifier == null)
                                {
                                    Console.WriteLine("Ce numéro de sécurité sociale n'existe pas");
                                    break;
                                }
                                Console.WriteLine("Que souhaitez-vous modifier ?\n1 - Nom\n2 - Adresse\n3 - Email\n4 - Téléphone");
                                string choix = Console.ReadLine();
                                int num = int.Parse(choix);

                                if (num == 1)
                                {
                                    Console.WriteLine("Quel est le nouveau nom ?");
                                    string nouveauNom = Console.ReadLine();
                                    clientAModifier.Nom = nouveauNom;
                                }
                                else if (num == 2)
                                {
                                    Console.WriteLine("Quel est la nouvelle adresse ?");
                                    string nouvAdresse = Console.ReadLine();
                                    clientAModifier.Adresse = nouvAdresse;
                                }
                                else if (num == 3)
                                {
                                    Console.WriteLine("Quel est le nouvel email ?");
                                    string nouvEmail = Console.ReadLine();
                                    clientAModifier.Email = nouvEmail;
                                }
                                else if (num == 4)
                                {
                                    Console.WriteLine("Quel est le nouveau numéro de téléphone ?");
                                    string nouvTel = Console.ReadLine();
                                    clientAModifier.Telephone = nouvTel;
                                }

                            }
                            else if (r == "4")
                            {
                                //Afficher les clients par ordre alphabétique
                                allClients.Sort();
                                allClients.ForEach(client => Console.Write(client.Nom + " " + client.Prenom + "\n"));
                            }
                            else if (r == "5")
                            {
                                //Afficher les clients par ville
                                List<Client> clientsTries = allClients.OrderBy(c => c.Adresse).ToList();
                                clientsTries.ForEach(client => Console.Write(client.Prenom + " " + client.Nom + " habite à " + client.Adresse + "\n"));
                            }
                            else if (r == "6")
                            {
                                //Afficher les meilleurs clients
                                if (allCommandes.Count != 0)
                                {
                                    string meilleurClient = allCommandes.GroupBy(commande => commande.Prenom).MaxBy(g => g.Count()).Key;
                                    string numSSMeilleurClient = allCommandes.GroupBy(commande => commande.NumSS).MaxBy(g => g.Count()).Key;
                                    double totalMeilleurClient = allCommandes.Where(commande => commande.Prenom == meilleurClient).Sum(commande => commande.Prix);
                                    Console.WriteLine(meilleurClient + " est votre meilleur client(e) avec " + totalMeilleurClient + "€ de montant cumulé ! Son numéro de sécurité social est le " + numSSMeilleurClient + ". Pourquoi pas lui offrir sa prochaine livraison ?");
                                }
                                else
                                {
                                    Console.WriteLine("Aucune commande n'a été créée");
                                }
                            }
                            else if (r == "7")
                            {
                                //Afficher la liste des commandes pour un client
                                Console.WriteLine("Quel son numéro de sécurité sociale ?");
                                string numSS = Console.ReadLine();
                                Client clientTrouve = allClients.Find(client => client.NumSS == numSS);
                                if (clientTrouve == null)
                                {
                                    Console.WriteLine("Aucun client ne correspond à ce numéro de sécurité sociale");
                                    break;
                                }
                                if (clientTrouve.HistoriqueCommande.Count == 0)
                                {
                                    Console.WriteLine(clientTrouve.Prenom + " n'a pas encore effectué de commande");
                                }
                                else
                                {
                                    Console.WriteLine(clientTrouve.ToString());
                                }
                            }
                            else if (r == "8")
                            {
                                //Offrir la livraison à un client
                                Console.WriteLine("Quel son numéro de sécurité sociale ?");
                                string numSS = Console.ReadLine();
                                Client clientTrouve = allClients.Find(client => client.NumSS == numSS);
                                if (clientTrouve == null)
                                {
                                    Console.WriteLine("Aucun client ne correspond à ce numéro de sécurité sociale");
                                    break;
                                }
                                else
                                {
                                    clientTrouve.Offrir();
                                    Console.WriteLine("La prochaine livraison de " + clientTrouve.Prenom + " sera gratuite !");
                                }
                            }
                            break;
                        case "2":
                            //Gestion des Salariés
                            Console.WriteLine("Que souhaitez-vous faire ?");
                            Console.WriteLine("1. Afficher l'organigramme");
                            Console.WriteLine("2. Ajouter un salarié");
                            Console.WriteLine("3. Supprimer un salarié");
                            Console.WriteLine("4. Afficher le nombre de livraisons par chauffeur");
                            string e = Console.ReadLine();
                            if (e == "1")
                            {
                                //Afficher l'organigramme
                                Organigramme newTransConnect = TransConnect.ChargerOrganigramme();
                                TransConnect.AfficherOrganigramme(newTransConnect.Root);
                            }
                            else if (e == "2")
                            {
                                //Ajouter un salarié
                                Organigramme newTransConnect = TransConnect.ChargerOrganigramme();

                                Console.WriteLine("Quel son numéro de sécurité sociale ?");
                                string numSS = Console.ReadLine();
                                Console.WriteLine("Quel est son nom ?");
                                string nom = Console.ReadLine();
                                Console.WriteLine("Quel est son prenom ?");
                                string prenom = Console.ReadLine();
                                Console.WriteLine("Quel est sa date de naissance ?(AAAA-MM-JJ)");
                                string naissance = Console.ReadLine();
                                DateTime dateNaissance = DateTime.MinValue;
                                try
                                {
                                    dateNaissance = DateTime.Parse(naissance);
                                }catch (Exception ex)
                                {
                                    Console.WriteLine("Erreur de format ! Veuillez entrer la date de naissance au format AAAA-MM-JJ :");
                                    naissance = Console.ReadLine();
                                    dateNaissance = DateTime.Parse(naissance);
                                }
                                Console.WriteLine("Quel est son adresse ?");
                                string adresse = Console.ReadLine();
                                Console.WriteLine("Quel est son email ?");
                                string email = Console.ReadLine();
                                Console.WriteLine("Quel est son telephone ?");
                                string telephone = Console.ReadLine();
                                Console.WriteLine("Quel est sa date d'entrée dans l'entreprise ?(AAAA-MM-JJ)");
                                string entree = Console.ReadLine();
                                DateTime dateEntree = DateTime.MinValue;
                                try
                                {
                                    dateEntree = DateTime.Parse(entree);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Erreur de format ! Veuillez entrer la date d'entrée dans l'entreprise au format AAAA-MM-JJ :");
                                    entree = Console.ReadLine();
                                    dateEntree = DateTime.Parse(entree);
                                }
                                Console.WriteLine("Quel son poste ?");
                                string poste = Console.ReadLine();
                                Console.WriteLine("Quel son salaire ?");
                                string salaire = Console.ReadLine();
                                double doubleSalaire = 0;
                                try
                                {
                                    doubleSalaire = Double.Parse(salaire);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Erreur de format ! Veuillez entrer le salaire avec un entier :");
                                    salaire = Console.ReadLine();
                                    doubleSalaire = Double.Parse(salaire);
                                }

                                Console.WriteLine("Quel est le nom de son futur manager ?");
                                string manager = Console.ReadLine();

                                Noeud noeudManager = newTransConnect.TrouverNoeudParNom(newTransConnect.Root, manager.ToUpper());

                                Console.WriteLine("Est-ce un chauffeur ? y/n");
                                string yn = Console.ReadLine();

                                if (yn == "y")
                                {
                                    Chauffeur nouvChauffeur = new Chauffeur(numSS, nom.ToUpper(), prenom, dateNaissance, adresse, email, telephone, dateEntree, poste, doubleSalaire, false);
                                    AllChauffeurs.Add(nouvChauffeur);
                                    Salarie nouveau = new Salarie(numSS, nom.ToUpper(), prenom, dateNaissance, adresse, email, telephone, dateEntree, poste, doubleSalaire);
                                    Noeud nouveauNoeud = new Noeud(nouveau);
                                    newTransConnect.AjouterDescendant(noeudManager, nouveauNoeud);
                                    newTransConnect.SauvegarderOrganigramme(newTransConnect);
                                    Console.WriteLine("\nSouhaitez la bienvenue à " + nouveau.Prenom + "!\n");
                                }
                                else
                                {
                                    Salarie nouveau = new Salarie(numSS, nom.ToUpper(), prenom, dateNaissance, adresse, email, telephone, dateEntree, poste, doubleSalaire);
                                    Noeud nouveauNoeud = new Noeud(nouveau);
                                    newTransConnect.AjouterDescendant(noeudManager, nouveauNoeud);
                                    newTransConnect.SauvegarderOrganigramme(newTransConnect);
                                    Console.WriteLine("\nSouhaitez la bienvenue à " + nouveau.Prenom + "!\n");
                                }
                            }
                            else if (e == "3")
                            {
                                //Supprimer un salarié
                                Organigramme newTransConnect = TransConnect.ChargerOrganigramme();

                                Console.WriteLine("Quel est le nom du salarié à licencier ?");
                                string salarieSupp = Console.ReadLine();
                                Noeud noeudSalarie = newTransConnect.TrouverNoeudParNom(newTransConnect.Root, salarieSupp.ToUpper());
                                Console.WriteLine("Quel est le nom de son manager ?");
                                string ManagerSalarieSupp = Console.ReadLine();
                                Noeud ManagerNoeudSalarie = newTransConnect.TrouverNoeudParNom(newTransConnect.Root, ManagerSalarieSupp.ToUpper());
                                if (noeudSalarie == null || ManagerSalarieSupp == null)
                                {
                                    Console.WriteLine("Aucun nom ne correspond à votre saisie");
                                }
                                else
                                {
                                    newTransConnect.SupprimerDescendant(ManagerNoeudSalarie, noeudSalarie);
                                    newTransConnect.SauvegarderOrganigramme(newTransConnect);
                                    Console.WriteLine("\nSalarié licencié avec succès\n");
                                }
                            }
                            else if (e == "4")
                            {
                                //Afficher le nombre de livraisons par chauffeur
                                var commandesChauffeur = allCommandes.GroupBy(commande => commande.Chauffeur);
                                if (commandesChauffeur.Count() != 0)
                                {
                                    foreach (var group in commandesChauffeur)
                                    {
                                        Console.WriteLine(group.Key + " a fait " + group.Count() + " livraison");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Aucune livraison n'a été programmée");
                                }
                            }
                            break;
                        case "3":
                            //Gestion des Commandes
                            Console.WriteLine("Que souhaitez-vous faire ?");
                            Console.WriteLine("1. Créer une commande");
                            Console.WriteLine("2. Modifier une commande");
                            Console.WriteLine("3. Simuler une commande");
                            Console.WriteLine("4. Afficher toutes les commandes");
                            Console.WriteLine("5. Afficher toutes les commandes sur une période");
                            Console.WriteLine("6. Afficher la moyenne de prix des commandes");
                            Console.WriteLine("7. Afficher la commande la plus chère");
                            Console.WriteLine("8. Afficher la file d'attente des commandes");
                            Console.WriteLine("9. Marque une commande comme livrée");
                            string a = Console.ReadLine();
                            if (a == "1")
                            {
                                //Créer une commande
                                Console.WriteLine("Indiquez le numéro de sécurité sociale du client qui passe la commande :");
                                string numSS = Console.ReadLine();
                                Client clientCommande = allClients.Find(client => client.NumSS == numSS);
                                if (clientCommande == null)
                                {
                                    Console.WriteLine("Ce numéro de sécurité sociale n'existe pas");
                                    break;
                                }
                                string adrDep = "Strasbourg";
                                Console.WriteLine("Sélectionnez la ville d'arrivée :\n1 - Brest\n2 - La Rochelle\n3 - Bordeaux\n4 - Toulouse");
                                string adrArr = Console.ReadLine();
                                int intAdrArr = int.Parse(adrArr);
                                int distanceTot = 0;

                                string[] animation = { "|", "/", "-", "\\" };
                                for (int i = 0; i < 40; i++)
                                {
                                    Console.Write("Calcul de votre itinéraire en cours " + animation[i % 4] + "\r");
                                    Thread.Sleep(100);
                                }

                                Console.Write("Voilà le parcours de votre livraison : ");
                                if (intAdrArr == 1)
                                {
                                    distanceTot = Dijkstra.Calculate(Strasbourg, Brest);
                                    adrArr = "Brest";
                                }
                                else if (intAdrArr == 2)
                                {
                                    distanceTot = Dijkstra.Calculate(Strasbourg, LaRochelle);
                                    adrArr = "La Rochelle";
                                }
                                else if (intAdrArr == 3)
                                {
                                    distanceTot = Dijkstra.Calculate(Strasbourg, Bordeaux);
                                    adrArr = "Bordeaux";
                                }
                                else if (intAdrArr == 4)
                                {
                                    distanceTot = Dijkstra.Calculate(Strasbourg, Toulouse);
                                    adrArr = "Toulouse";
                                }

                                Thread.Sleep(2000);

                                for (int i = 0; i < 30; i++)
                                {
                                    Console.Write("Nous cherchons un chauffeur pour vous livrer " + animation[i % 4] + "\r");
                                    Thread.Sleep(100);
                                }

                                Console.Write("Chargement terminé !");

                                Chauffeur chauffeurDispo = AllChauffeurs.Find(chauffeur => chauffeur.PeutEffectuerLivraison());
                                if (chauffeurDispo == null)
                                {
                                    Console.WriteLine("Désolé aucun chauffeur n'est disponible");
                                }
                                else
                                {
                                    Console.Write(" " + chauffeurDispo.Prenom + " sera votre chauffeur               \n");
                                    chauffeurDispo.EffectuerLivraison();

                                }

                                Thread.Sleep(2000);

                                Console.WriteLine("Indiquez la date de livraison que vous souhaitez : ");
                                string livraison = Console.ReadLine();
                                DateTime dateLivraison = DateTime.Parse(livraison);
                                if (dateLivraison < DateTime.Today)
                                {
                                    Console.WriteLine("Impossible de livrer à cette date");
                                    break;
                                }

                                Console.WriteLine("Sélectionnez le type de véhicule pour la livraison :\n1 - Voiture\n2 - Camionette\n3 - Camion frigorifique\n4 - Camion Benne\n5 - Camion citerne");
                                string choix = Console.ReadLine();
                                int d = int.Parse(choix);
                                double prixFinal = 0;
                                int id = new Random().Next(100);

                                if (d == 1)
                                {
                                    prixFinal = voitureLivraison.AppliquerMajoration(80, distanceTot);
                                    Commande c1 = new Commande(clientCommande, adrDep, adrArr, voitureLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                    allCommandes.Add(c1);
                                    Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                    FileAttente.Ajouter(c1, comparerDate);
                                }
                                else if (d == 2)
                                {
                                    prixFinal = camionnetteLivraison.AppliquerMajoration(80, distanceTot);
                                    Commande c1 = new Commande(clientCommande, adrDep, adrArr, camionnetteLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                    allCommandes.Add(c1);
                                    ;
                                    Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                    FileAttente.Ajouter(c1, comparerDate);
                                }
                                else if (d == 3)
                                {
                                    prixFinal = frigoLivraison.AppliquerMajoration(80, distanceTot);
                                    Commande c1 = new Commande(clientCommande, adrDep, adrArr, frigoLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                    allCommandes.Add(c1);
                                    ;
                                    Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                    FileAttente.Ajouter(c1, comparerDate);
                                }
                                else if (d == 4)
                                {
                                    prixFinal = benneLivraison.AppliquerMajoration(80, distanceTot);
                                    Commande c1 = new Commande(clientCommande, adrDep, adrArr, benneLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                    allCommandes.Add(c1);
                                    ;
                                    Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                    FileAttente.Ajouter(c1, comparerDate);
                                }
                                else if (d == 5)
                                {
                                    prixFinal = citerneLivraison.AppliquerMajoration(80, distanceTot);
                                    Commande c1 = new Commande(clientCommande, adrDep, adrArr, citerneLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                    allCommandes.Add(c1);
                                    ;
                                    Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                    FileAttente.Ajouter(c1, comparerDate);
                                }
                            }
                            else if (a == "2")
                            {
                                //Modifier une commande
                                Console.WriteLine("Quel est votre numéro de commande ?");
                                string id = Console.ReadLine();
                                int intId = int.Parse(id);
                                Commande commandeAModifier = allCommandes.Find(commande => commande.Id == intId);
                                if (commandeAModifier == null)
                                {
                                    Console.WriteLine("Aucune commande ne correspond à ce numéro de commande");
                                    break;
                                }
                                Console.WriteLine("Que souhaitez-vous modifier ?\n1 - La ville de livraison\n2 - La date de livraison");
                                string choix = Console.ReadLine();
                                int intChoix = int.Parse(choix);

                                if (intChoix == 1)
                                {
                                    Console.WriteLine("Sélectionnez la ville d'arrivée :\n1 - Brest\n2 - La Rochelle\n3 - Bordeaux\n4 - Toulouse");
                                    string adrArr = Console.ReadLine();
                                    int intAdrArr = int.Parse(adrArr);
                                    int distanceTot = 0;

                                    string[] animation = { "|", "/", "-", "\\" };
                                    for (int i = 0; i < 40; i++)
                                    {
                                        Console.Write("Calcul de votre itinéraire en cours " + animation[i % 4] + "\r");
                                        Thread.Sleep(100);
                                    }

                                    Console.Write("Voilà le parcours de votre livraison : ");
                                    if (intAdrArr == 1)
                                    {
                                        distanceTot = Dijkstra.Calculate(Strasbourg, Brest);
                                        adrArr = "Brest";
                                    }
                                    else if (intAdrArr == 2)
                                    {
                                        distanceTot = Dijkstra.Calculate(Strasbourg, LaRochelle);
                                        adrArr = "La Rochelle";
                                    }
                                    else if (intAdrArr == 3)
                                    {
                                        distanceTot = Dijkstra.Calculate(Strasbourg, Bordeaux);
                                        adrArr = "Bordeaux";
                                    }
                                    else if (intAdrArr == 4)
                                    {
                                        distanceTot = Dijkstra.Calculate(Strasbourg, Toulouse);
                                        adrArr = "Toulouse";
                                    }

                                    Console.WriteLine("Sélectionnez le type de véhicule pour la livraison :\n1 - Voiture\n2 - Camionette\n3 - Camion frigorifique\n4 - Camion Benne\n5 - Camion citerne");
                                    string veh = Console.ReadLine();
                                    int d = int.Parse(veh);
                                    double prixFinal = 0;

                                    if (d == 1)
                                    {
                                        prixFinal = voitureLivraison.AppliquerMajoration(80, distanceTot);
                                    }
                                    if (d == 2)
                                    {
                                        prixFinal = camionnetteLivraison.AppliquerMajoration(80, distanceTot);
                                    }
                                    if (d == 3)
                                    {
                                        prixFinal = frigoLivraison.AppliquerMajoration(80, distanceTot);
                                    }
                                    if (d == 4)
                                    {
                                        prixFinal = benneLivraison.AppliquerMajoration(80, distanceTot);
                                    }
                                    if (d == 5)
                                    {
                                        prixFinal = citerneLivraison.AppliquerMajoration(80, distanceTot);
                                    }

                                    commandeAModifier.AdresseArrivee = adrArr;
                                    commandeAModifier.Prix = prixFinal;
                                    Console.WriteLine("Commande modifiée avec succès");
                                    break;
                                }
                                else if (intChoix == 2)
                                {
                                    Console.WriteLine("Quel est la nouvelle date de livraison ?");
                                    string date = Console.ReadLine();
                                    DateTime vraiDate = DateTime.Parse(date);
                                    if (vraiDate < DateTime.Today)
                                    {
                                        Console.WriteLine("Impossible de livrer à cette date");
                                        break;
                                    }
                                    commandeAModifier.Date = vraiDate;
                                    Console.WriteLine("Commande modifiée avec succès");
                                }

                            }
                            else if (a == "3")
                            {
                                //Simuler une commande
                                Console.WriteLine("Sélectionnez la ville d'arrivée :\n1 - Brest\n2 - La Rochelle\n3 - Bordeaux\n4 - Toulouse");
                                string adrArr = Console.ReadLine();
                                int intAdrArr = int.Parse(adrArr);
                                int distanceTot = 0;

                                string[] animation = { "|", "/", "-", "\\" };
                                for (int i = 0; i < 40; i++)
                                {
                                    Console.Write("Calcul de votre itinéraire en cours " + animation[i % 4] + "\r");
                                    Thread.Sleep(100);
                                }

                                Console.Write("Voilà la simulation de votre livraison : ");
                                if (intAdrArr == 1)
                                {
                                    distanceTot = Dijkstra.Calculate(Strasbourg, Brest);
                                    adrArr = "Brest";
                                }
                                else if (intAdrArr == 2)
                                {
                                    distanceTot = Dijkstra.Calculate(Strasbourg, LaRochelle);
                                    adrArr = "La Rochelle";
                                }
                                else if (intAdrArr == 3)
                                {
                                    distanceTot = Dijkstra.Calculate(Strasbourg, Bordeaux);
                                    adrArr = "Bordeaux";
                                }
                                else if (intAdrArr == 4)
                                {
                                    distanceTot = Dijkstra.Calculate(Strasbourg, Toulouse);
                                    adrArr = "Toulouse";
                                }

                                Thread.Sleep(2000);

                                Console.WriteLine("Sélectionnez le type de véhicule pour la livraison :\n1 - Voiture\n2 - Camionette\n3 - Camion frigorifique\n4 - Camion Benne\n5 - Camion citerne");
                                string choix = Console.ReadLine();
                                int d = int.Parse(choix);
                                double prixFinal = 0;
                                int id = new Random().Next(100);

                                if (d == 1)
                                {
                                    prixFinal = voitureLivraison.AppliquerMajoration(80, distanceTot);
                                    Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                                }
                                else if (d == 2)
                                {
                                    prixFinal = camionnetteLivraison.AppliquerMajoration(80, distanceTot);
                                    Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                                }
                                else if (d == 3)
                                {
                                    prixFinal = frigoLivraison.AppliquerMajoration(80, distanceTot);
                                    Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                                }
                                else if (d == 4)
                                {
                                    prixFinal = benneLivraison.AppliquerMajoration(80, distanceTot);
                                    Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                                }
                                else if (d == 5)
                                {
                                    prixFinal = citerneLivraison.AppliquerMajoration(80, distanceTot);
                                    Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                                }
                            }
                            else if (a == "4")
                            {
                                //Afficher toutes les commandes
                                if (allCommandes.Count != 0)
                                {
                                    allCommandes.ForEach(commande => Console.WriteLine(commande.ToString()));
                                }
                                else
                                {
                                    Console.WriteLine("Aucune commande n'a été créée");
                                }
                            }
                            else if (a == "5")
                            {
                                //Afficher toutes les commandes dans une période
                                Console.WriteLine("Entrez la date de début : ");
                                string debut = Console.ReadLine();
                                DateTime dateDebut = DateTime.MinValue;
                                try
                                {
                                    dateDebut = DateTime.Parse(debut);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Erreur de format ! Veuillez entrer la date au format AAAA-MM-JJ :");
                                    debut = Console.ReadLine();
                                    dateDebut = DateTime.Parse(debut);
                                }
                                Console.WriteLine("Entrez la date de fin : ");
                                string fin = Console.ReadLine();
                                DateTime dateFin = DateTime.MinValue;
                                try
                                {
                                    dateFin = DateTime.Parse(fin);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Erreur de format ! Veuillez entrer la date au format AAAA-MM-JJ :");
                                    fin = Console.ReadLine();
                                    dateFin = DateTime.Parse(fin);
                                }

                                List<Commande> commandeDate = allCommandes.Where(commande => commande.Date > dateDebut && commande.Date < dateFin).ToList();

                                if (commandeDate.Count != 0)
                                {
                                    commandeDate.ForEach(commande => Console.Write("\nCommande du " + commande.Date.ToString("dd-MM-yyyy") + " livrée par " + commande.Chauffeur + "\n"));
                                }
                                else
                                {
                                    Console.WriteLine("Aucune commande n'a été créée sur cette période");
                                }
                            }
                            else if (a == "6")
                            {
                                //Afficher la moyenne de prix des commandes
                                double totalMeilleurClient = allCommandes.Sum(commande => commande.Prix);
                                double moyenneCommande = totalMeilleurClient / allCommandes.Count();
                                if (!double.IsNaN(moyenneCommande))
                                {
                                    Console.WriteLine("Le prix moyen d'une commande est de " + moyenneCommande + "€");
                                }
                                else
                                {
                                    Console.WriteLine("Aucune commande n'a été créée");
                                }
                            }
                            else if (a == "7")
                            {
                                //Afficher la commande la plus chère
                                if (allCommandes.Count !=0)
                                {
                                    allCommandes.Sort();
                                    Console.WriteLine("La commande la plus chère a couté " + allCommandes[^1].Prix + "€ à " + allCommandes[^1].Prenom);
                                }
                                else
                                {
                                    Console.WriteLine("Aucune commande n'a été créée");
                                }
                                
                            }
                            else if (a == "8")
                            {
                                //Afficher la file d'attente des commandes
                                if (FileAttente != null)
                                {
                                    FileAttente.Afficher();
                                }
                                else
                                {
                                    Console.WriteLine("Aucune commande n'a été créée");
                                }
                            }
                            else if (a == "9")
                            {
                                //Marque une commande comme livrées
                                FileAttente.SupprimerDernier();
                                Console.WriteLine("La commande la plus proche de la date d'aujourd'hui a été marquée comme livrée");
                            }
                            break;
                        case "4":
                            Console.Clear();
                            deco = true;
                            break;
                        case "5":
                            Environment.Exit(1);
                            break;
                }
            }
        }
            else
            {
            
                while (!deco)
                {
                    Console.WriteLine("\n1. J'ai déjà une commande");
                    Console.WriteLine("2. Je n'ai pas de commande");
                    Console.WriteLine("3. Déconnexion");
                    Console.WriteLine("4. Quitter\n");
                    string tt = Console.ReadLine();

                    switch (tt)
                    {
                        case "1":

                            Console.WriteLine("\nQue souhaitez-vous faire ?\n");
                            Console.WriteLine("1. Modifier une commande");
                            Console.WriteLine("2. Afficher mes commandes");
                            string cr = Console.ReadLine();

                        if (cr == "1")
                        {
                            //Modifier une commande
                            Console.WriteLine("Quel est votre numéro de commande ?");
                            string id = Console.ReadLine();
                            int intId = int.Parse(id);
                            Commande commandeAModifier = allCommandes.Find(commande => commande.Id == intId);
                            if (commandeAModifier == null)
                            {
                                Console.WriteLine("Aucune commande ne correspond à ce numéro de commande");
                                break;
                            }
                            Console.WriteLine("Que souhaitez-vous modifier ?\n1 - La ville de livraison\n2 - La date de livraison");
                            string choix = Console.ReadLine();
                            int intChoix = int.Parse(choix);

                            if (intChoix == 1)
                            {
                                    Console.WriteLine("Sélectionnez la ville d'arrivée :\n1 - Brest\n2 - La Rochelle\n3 - Bordeaux\n4 - Toulouse");
                                    string adrArr = Console.ReadLine();
                                    int intAdrArr = int.Parse(adrArr);
                                    int distanceTot = 0;

                                    string[] animation = { "|", "/", "-", "\\" };
                                    for (int i = 0; i < 40; i++)
                                    {
                                        Console.Write("Calcul de votre itinéraire en cours " + animation[i % 4] + "\r");
                                        Thread.Sleep(100);
                                    }

                                    Console.Write("Voilà le parcours de votre livraison : ");
                                    if (intAdrArr == 1)
                                    {
                                        distanceTot = Dijkstra.Calculate(Strasbourg, Brest);
                                        adrArr = "Brest";
                                    }
                                    else if (intAdrArr == 2)
                                    {
                                        distanceTot = Dijkstra.Calculate(Strasbourg, LaRochelle);
                                        adrArr = "La Rochelle";
                                    }
                                    else if (intAdrArr == 3)
                                    {
                                        distanceTot = Dijkstra.Calculate(Strasbourg, Bordeaux);
                                        adrArr = "Bordeaux";
                                    }
                                    else if (intAdrArr == 4)
                                    {
                                        distanceTot = Dijkstra.Calculate(Strasbourg, Toulouse);
                                        adrArr = "Toulouse";
                                    }

                                Console.WriteLine("Sélectionnez le type de véhicule pour la livraison :\n1 - Voiture\n2 - Camionette\n3 - Camion frigorifique\n4 - Camion Benne\n5 - Camion citerne");
                                string veh = Console.ReadLine();
                                int d = int.Parse(veh);
                                double prixFinal = 0;

                                if (d == 1)
                                {
                                    prixFinal = voitureLivraison.AppliquerMajoration(80, distanceTot);
                                }
                                if (d == 2)
                                {
                                    prixFinal = camionnetteLivraison.AppliquerMajoration(80, distanceTot);
                                }
                                if (d == 3)
                                {
                                    prixFinal = frigoLivraison.AppliquerMajoration(80, distanceTot);
                                }
                                if (d == 4)
                                {
                                    prixFinal = benneLivraison.AppliquerMajoration(80, distanceTot);
                                }
                                if (d == 5)
                                {
                                    prixFinal = citerneLivraison.AppliquerMajoration(80, distanceTot);
                                }

                                commandeAModifier.AdresseArrivee = adrArr;
                                commandeAModifier.Prix = prixFinal;
                                Console.WriteLine("Commande modifiée avec succès");
                                break;
                                }
                            else if (intChoix == 2)
                            {
                                Console.WriteLine("Quel est la nouvelle date de livraison ?");
                                string date = Console.ReadLine();
                                DateTime vraiDate = DateTime.Parse(date);
                                if (vraiDate < DateTime.Today)
                                {
                                    Console.WriteLine("Impossible de livrer à cette date");
                                    break;
                                }
                                commandeAModifier.Date = vraiDate;
                                Console.WriteLine("Commande modifiée avec succès");
                                }
                        }
                        else if (cr == "2")
                        {
                            //Afficher les commandes
                            Console.WriteLine("Indiquez votre numéro de sécurité sociale :");
                            string numSS = Console.ReadLine();
                            Client clientCommande = allClients.Find(client => client.NumSS == numSS);
                            if (clientCommande == null)
                            {
                                Console.WriteLine("Ce numéro de sécurité sociale n'existe pas");
                                break;
                            }
                            if (allCommandes.Count == 0)
                            {
                                Console.WriteLine("Aucune commande n'a été créée");
                                break;
                            }
                            else
                            {
                                List<Commande> afficherClient = allCommandes.FindAll(client => client.NumSS == numSS);
                                afficherClient.ForEach(commande => Console.WriteLine(commande.ToString()));
                            }
                            break;
                        }
                            break;

                        case "2":

                            Console.WriteLine("\nQue souhaitez-vous faire ?\n");
                            Console.WriteLine("1. Créer une commande");
                            Console.WriteLine("2. Simuler une commande");
                            string pp = Console.ReadLine();

                        if (pp == "1")
                        {
                            //Créer une commande
                            Console.WriteLine("Indiquez votre numéro de sécurité sociale :");
                            string numSS = Console.ReadLine();
                            Client clientCommande = allClients.Find(client => client.NumSS == numSS);
                            if (clientCommande == null)
                            {
                                Console.WriteLine("Ce numéro de sécurité sociale n'existe pas");
                                break;
                            }
                            string adrDep = "Strasbourg";
                            Console.WriteLine("Sélectionnez la ville d'arrivée :\n1 - Brest\n2 - La Rochelle\n3 - Bordeaux\n4 - Toulouse");
                            string adrArr = Console.ReadLine();
                            int intAdrArr = int.Parse(adrArr);
                            int distanceTot = 0;

                            string[] animation = { "|", "/", "-", "\\" };
                            for (int i = 0; i < 40; i++)
                            {
                                Console.Write("Calcul de votre itinéraire en cours " + animation[i % 4] + "\r");
                                Thread.Sleep(100);
                            }

                            Console.Write("Voilà le parcours de votre livraison : ");
                            if (intAdrArr == 1)
                            {
                                distanceTot = Dijkstra.Calculate(Strasbourg, Brest);
                                adrArr = "Brest";
                            }
                            else if (intAdrArr == 2)
                            {
                                distanceTot = Dijkstra.Calculate(Strasbourg, LaRochelle);
                                adrArr = "La Rochelle";
                            }
                            else if (intAdrArr == 3)
                            {
                                distanceTot = Dijkstra.Calculate(Strasbourg, Bordeaux);
                                adrArr = "Bordeaux";
                            }
                            else if (intAdrArr == 4)
                            {
                                distanceTot = Dijkstra.Calculate(Strasbourg, Toulouse);
                                adrArr = "Toulouse";
                            }

                            Thread.Sleep(2000);

                            for (int i = 0; i < 30; i++)
                            {
                                Console.Write("Nous cherchons un chauffeur pour vous livrer " + animation[i % 4] + "\r");
                                Thread.Sleep(100);
                            }

                            Console.Write("Chargement terminé !");

                            Chauffeur chauffeurDispo = AllChauffeurs.Find(chauffeur => chauffeur.PeutEffectuerLivraison());
                            if (chauffeurDispo == null)
                            {
                                Console.WriteLine("Désolé aucun chauffeur n'est disponible");
                            }
                            else
                            {
                                Console.Write(" " + chauffeurDispo.Prenom + " sera votre chauffeur               \n");
                                chauffeurDispo.EffectuerLivraison();

                            }

                            Thread.Sleep(2000);

                            Console.WriteLine("Indiquez la date de livraison que vous souhaitez : ");
                            string livraison = Console.ReadLine();
                            DateTime dateLivraison = DateTime.Parse(livraison);
                            if (dateLivraison < DateTime.Today)
                            {
                                Console.WriteLine("Impossible de livrer à cette date");
                                break;
                            }

                            Console.WriteLine("Sélectionnez le type de véhicule pour la livraison :\n1 - Voiture\n2 - Camionette\n3 - Camion frigorifique\n4 - Camion Benne\n5 - Camion citerne");
                            string choix = Console.ReadLine();
                            int d = int.Parse(choix);
                            double prixFinal = 0;
                            int id = new Random().Next(100);

                            if (d == 1)
                            {
                                prixFinal = voitureLivraison.AppliquerMajoration(80, distanceTot);
                                Commande c1 = new Commande(clientCommande, adrDep, adrArr, voitureLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                allCommandes.Add(c1);
                                Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                FileAttente.Ajouter(c1, comparerDate);
                                }
                            else if (d == 2)
                            {
                                prixFinal = camionnetteLivraison.AppliquerMajoration(80, distanceTot);
                                Commande c1 = new Commande(clientCommande, adrDep, adrArr, camionnetteLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                allCommandes.Add(c1);
                                ;
                                Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                FileAttente.Ajouter(c1, comparerDate);
                                }
                            else if (d == 3)
                            {
                                prixFinal = frigoLivraison.AppliquerMajoration(80, distanceTot);
                                Commande c1 = new Commande(clientCommande, adrDep, adrArr, frigoLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                allCommandes.Add(c1);
                                ;
                                Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                FileAttente.Ajouter(c1, comparerDate);
                                }
                            else if (d == 4)
                            {
                                prixFinal = benneLivraison.AppliquerMajoration(80, distanceTot);
                                Commande c1 = new Commande(clientCommande, adrDep, adrArr, benneLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                allCommandes.Add(c1);
                                ;
                                Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                FileAttente.Ajouter(c1, comparerDate);
                                }
                            else if (d == 5)
                            {
                                prixFinal = citerneLivraison.AppliquerMajoration(80, distanceTot);
                                Commande c1 = new Commande(clientCommande, adrDep, adrArr, citerneLivraison, prixFinal, chauffeurDispo, dateLivraison, id);
                                allCommandes.Add(c1);
                                ;
                                Console.WriteLine("Merci de votre commande ! Votre numéro de commande est " + id);
                                FileAttente.Ajouter(c1, comparerDate);
                                }
                            }
                        else if (pp == "2")
                        {
                            //Simuler une commande
                            Console.WriteLine("Sélectionnez la ville d'arrivée :\n1 - Brest\n2 - La Rochelle\n3 - Bordeaux\n4 - Toulouse");
                            string adrArr = Console.ReadLine();
                            int intAdrArr = int.Parse(adrArr);
                            int distanceTot = 0;

                            string[] animation = { "|", "/", "-", "\\" };
                            for (int i = 0; i < 40; i++)
                            {
                                Console.Write("Calcul de votre itinéraire en cours " + animation[i % 4] + "\r");
                                Thread.Sleep(100);
                            }

                            Console.Write("Voilà la simulation de votre livraison : ");
                            if (intAdrArr == 1)
                            {
                                distanceTot = Dijkstra.Calculate(Strasbourg, Brest);
                                adrArr = "Brest";
                            }
                            else if (intAdrArr == 2)
                            {
                                distanceTot = Dijkstra.Calculate(Strasbourg, LaRochelle);
                                adrArr = "La Rochelle";
                            }
                            else if (intAdrArr == 3)
                            {
                                distanceTot = Dijkstra.Calculate(Strasbourg, Bordeaux);
                                adrArr = "Bordeaux";
                            }
                            else if (intAdrArr == 4)
                            {
                                distanceTot = Dijkstra.Calculate(Strasbourg, Toulouse);
                                adrArr = "Toulouse";
                            }

                            Thread.Sleep(2000);

                            Console.WriteLine("Sélectionnez le type de véhicule pour la livraison :\n1 - Voiture\n2 - Camionette\n3 - Camion frigorifique\n4 - Camion Benne\n5 - Camion citerne");
                            string choix = Console.ReadLine();
                            int d = int.Parse(choix);
                            double prixFinal = 0;
                            int id = new Random().Next(100);

                            if (d == 1)
                            {
                                prixFinal = voitureLivraison.AppliquerMajoration(80, distanceTot);
                                Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                            }
                            else if (d == 2)
                            {
                                prixFinal = camionnetteLivraison.AppliquerMajoration(80, distanceTot);
                                Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                            }
                            else if (d == 3)
                            {
                                prixFinal = frigoLivraison.AppliquerMajoration(80, distanceTot);
                                Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                            }
                            else if (d == 4)
                            {
                                prixFinal = benneLivraison.AppliquerMajoration(80, distanceTot);
                                Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                            }
                            else if (d == 5)
                            {
                                prixFinal = citerneLivraison.AppliquerMajoration(80, distanceTot);
                                Console.WriteLine("Le prix de votre commande serait de " + prixFinal + "€");
                            }
                            }
                    break;

                    case "3":
                        Console.Clear();
                        deco = true;
                        break;
                    case "4":
                        Environment.Exit(1);
                        break;
                    }
                }
            }
        }
    }
}