﻿using System;
namespace ProjetRENOIR
{
	public class CamionCiterne : Camion, IMajoration
	{
		string cuve;

		public CamionCiterne(string immat, int volume, string matieres, string cuve) : base(immat, volume, matieres)
		{
			this.cuve = cuve;
		}

        public override string ToString()
        {
            return base.ToString() + " Cuve : " + cuve;
        }

        public double AppliquerMajoration(int prixBase, int km)
        {
            return prixBase * 1.70 + (km / 100.0);
        }
    }
}

