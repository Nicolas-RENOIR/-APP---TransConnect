﻿using System;
using System.Xml.Linq;

namespace ProjetRENOIR
{
    public class Graph
	{
        private List<Noeud> Noeuds;

        public Graph()
        {
            Noeuds = new List<Noeud>();
        }

        public void Ajouter(Noeud n)
        {
            Noeuds.Add(n);
        }

        public void Supprimer(Noeud n)
        {
            Noeuds.Remove(n);
        }

        public List<Noeud> GetNoeuds()
        {
            return Noeuds.ToList();
        }
    }
}

