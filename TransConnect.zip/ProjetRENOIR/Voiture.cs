﻿using System;
namespace ProjetRENOIR
{
	public class Voiture : Vehicule, IMajoration
    {
		int nbPassager;

		public Voiture(string immat, int nbPassager) : base (immat)
		{
			this.nbPassager = nbPassager;
		}

        public override string ToString()
        {
            return base.ToString() + " Nombre de passagers " + nbPassager;
        }

        public double AppliquerMajoration(int prixBase, int km)
        {
            return prixBase * 1.05 + (km / 100.0);
        }
    }
}

