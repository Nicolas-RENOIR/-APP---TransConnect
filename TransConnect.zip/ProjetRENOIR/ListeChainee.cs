﻿using System;
namespace ProjetRENOIR
{
	public class ListeChainee<T> where T : Commande
    {
        private NoeudChainee<T> tete;

        public ListeChainee()
		{
            tete = null;
        }

        /// <summary>Ajoute un élément dans la liste chaînée de manière ordonnée selon un comparateur spécifié</summary>
        /// <param name="x">L'élément à ajouter à la liste.</param>
        /// <param name="comparer">Le comparateur qui détermine l'ordre des éléments dans la liste.</param>
        public void Ajouter(T x, Comparer<T> comparer)
        {
            NoeudChainee<T> nouveauNoeud = new NoeudChainee<T>(x);// Création d'un nouveau nœud pour l'élément à ajouter
            if (tete == null || comparer(x, tete.Donnee) > 0)// Si la liste est vide ou si l'élément doit être inséré avant la tête actuelle
            {
                nouveauNoeud.Suivant = tete;// Le nouveau nœud est inséré avant la tête actuelle
                tete = nouveauNoeud;// Le nouveau nœud devient la nouvelle tête de la liste
            }
            else
            {
                NoeudChainee<T> courant = tete;
                // Parcourir la liste pour trouver le point d'insertion où l'élément suivant est plus grand que l'élément à insérer
                while (courant.Suivant != null && comparer(x, courant.Suivant.Donnee) < 0)
                {
                    courant = courant.Suivant;
                }
                // Insérer le nouveau nœud après l'élément 'courant'
                nouveauNoeud.Suivant = courant.Suivant;
                courant.Suivant = nouveauNoeud;
            }
        }

        public void SupprimerDernier()
        {
            if (tete == null)
            {
                Console.WriteLine("Aucune commande n'a été créée");
                return;
            }

            if (tete.Suivant == null)
            {
                tete = null;
                return;
            }

            NoeudChainee<T> courant = tete;// Sauvegarde de la tête
            while (courant.Suivant.Suivant != null)// Parcourt la liste jusqu'à l'avant-dernier élément.
            {
                courant = courant.Suivant;
            }

            courant.Suivant = null;// Mettre le dernier élément à null
        }


        public void Afficher()
        {
            NoeudChainee<T> courant = tete;
            if (tete == null)
            {
                Console.WriteLine("Aucune commande n'a été créée");
            }

            while (courant != null)
            {
                Console.WriteLine(courant.Donnee.ToStringFile());
                courant = courant.Suivant;
            }
        }
    }
}

