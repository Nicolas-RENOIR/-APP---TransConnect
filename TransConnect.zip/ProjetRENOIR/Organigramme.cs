﻿using System;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ProjetRENOIR
{
    [Serializable]
    public class Organigramme
	{
        public Noeud root { get; set; }

        public Organigramme(Salarie DG)
		{
            this.root = new Noeud(DG);
        }

        public Organigramme()
        {
        }

        public Noeud Root
        {
            get { return this.root; }
        }

        /// <summary>Ajoute un nœud fils à un nœud parent donné.</summary>
        /// <param name="parent">Le nœud parent auquel on veut ajouter un fils.</param>
        /// <param name="n">Le nœud fils à ajouter.</param>
        public void AjouterDescendant(Noeud parent, Noeud n)
        {
            if (parent != null && n != null)
            {
                parent.AjouterFils(n);
            }
            else
            {
                Console.WriteLine("Impossible car le parent ou le descendant est null");
            }
        }

        /// <summary>Supprime le nœud fils d'un nœud parent donné.</summary>
        /// <param name="parent">Le nœud parent dont on veut supprimer le fils.</param>
        /// <param name="fiston">Le nœud fils à supprimer.</param>
        public void SupprimerDescendant(Noeud parent, Noeud fiston)
        {
            if (parent != null && fiston != null)
            {
                if (!fiston.EstFeuille())
                {
                    foreach (Noeud enfant in fiston.Enfant)
                    {
                        parent.AjouterFils(enfant);
                    }
                }
                parent.SupprimerFils(fiston);
            }
        }

        /// <summary>Affiche récursivement l'organigramme à partir d'un nœud</summary>
        /// <param name="n">Le nœud où commence l'affichage de l'organigramme.</param>
        /// <param name="a">Le nombre d'espaces initial.</param>
        public void AfficherOrganigramme(Noeud n, string a = "", int index = 0)
        {
            if (n == null) return;

            if (index == 0)// Si première entrée, affichez le nom du salarié
            {
                Console.WriteLine(a + "―-- " + n.Salarie.Nom);
            }

            // Vérifiez si l'index inférieur au nombre d'enfants que le nœud a
            if (index < n.Enfant.Count)
            {
                // Afficher l'enfant actuel et augmentez l'indentation
                AfficherOrganigramme(n.Enfant[index], a + "     ");

                // Revenir au même nœud mais pour considérer le prochain enfant
                AfficherOrganigramme(n, a, index + 1);
            }
        }




        /// <summary>Recherche récursivement un nœud en fonction du nom d'un salarié.</summary>
        /// <param name="n">Le nœud dans lequel commence la recherche.</param>
        /// <param name="s">Le nom du salarié recherché.</param>
        /// <returns>Le nœud trouvé contenant le salarié avec le nom recherché, ou null si non trouvé.</returns>
        public Noeud TrouverNoeudParNom(Noeud n, string s)
        {
            if (n == null) return null;

            // Vérifie si le nœud actuel contient le salarié recherché
            if (n.Salarie != null && n.Salarie.Nom == s) return n;

            // Récursivement cherche dans chaque enfant
            foreach (Noeud fils in n.Enfant)
            {
                Noeud resultat = TrouverNoeudParNom(fils, s); // Recherche récursive dans les enfants
                if (resultat != null) return resultat;
            }

            return null; // Retourne null si aucun nœud n'est trouvé
        }


        /// <summary>Sauvegarde l'organigramme dans un fichier xml.</summary>
        /// <param name="o">Organigramme a sauvegarder.</param>
        /// <returns>Un fichier xml contenant les informations de l'organigramme.</returns>
        public void SauvegarderOrganigramme(Organigramme o)
        {
            // Crée une instance de XmlSerializer pour le type Organigramme
            XmlSerializer sauvegarde = new XmlSerializer(typeof(Organigramme));

            try
            {
                // Utilise FileStream pour ouvrir un fichier nommé "organigramme.xml" en mode écriture
                using (FileStream fileStream = new FileStream("organigramme.xml", FileMode.Create))
                {
                    // Serialize (ou convertit) l'objet 'o' en XML
                    sauvegarde.Serialize(fileStream, o);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur : " + ex.Message);
            }
        }


        /// <summary>Charge l'oganigramme sauvegardé dans un fichier xml.</summary>
        /// <returns>Un objet organigramme contenant toutes les informations du fichier xml.</returns>
        public Organigramme ChargerOrganigramme()
        {
            Organigramme organigramme = null;// Pour gérer le cas où la désérialisation échoue

            if (File.Exists("organigramme.xml"))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Organigramme));// Crée un XmlSerializer pour désérialiser un objet de type Organigramme

                using (FileStream fileStream = new FileStream("organigramme.xml", FileMode.Open))
                {
                    try
                    {
                        organigramme = (Organigramme)serializer.Deserialize(fileStream);// Test de désérialiser le contenu du fichier XML en un objet Organigramme
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Une erreur est survenue lors de la désérialisation " + ex.Message);
                    }
                }
            }
            else
            {
                Console.WriteLine("Aucune sauvegarde de l'organigramme trouvée");
            }

            return organigramme;
        }
    }
}

