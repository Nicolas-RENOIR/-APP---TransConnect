﻿using System;
namespace ProjetRENOIR
{
	public class CamionFrigo : Camion, IMajoration
	{
		int nbGrpElectro;

        public CamionFrigo(string immat, int volume, string matieres, int nbGrpElectro) : base(immat, volume, matieres)
        {
			this.nbGrpElectro = nbGrpElectro;
        }

		public override string ToString()
        {
            return base.ToString() + " Nombre de groupe électrogène : " + nbGrpElectro;
        }

        public double AppliquerMajoration(int prixBase, int km)
        {
            return prixBase * 1.55 + (km / 100.0);
        }
    }
}

