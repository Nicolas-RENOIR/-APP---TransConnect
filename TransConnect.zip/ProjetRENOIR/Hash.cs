﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace ProjetRENOIR
{
	public static class Hash
	{
		public static string ChiffrerMDP(string passwd)
		{
            using (SHA256 sha256Hash = SHA256.Create())// Utilisation d'un objet SHA256
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(passwd));// Convertit 'passwd' en un tableau de bytes et calcule le hash SHA-256

                StringBuilder builder = new StringBuilder();// Utilisé pour construire le résultat du hash en une chaîne hexadécimale
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));// Convertit chaque byte en une chaîne hexadécimale et l'ajoute au StringBuilder
                }
                return builder.ToString();// Retourne le hash SHA-256 de 'passwd'
            }
        }

        public static bool LireMotdePasse(string iden, string passwd)
        {
            try
            {
                string[] lines = File.ReadAllLines("log.csv");

                foreach (string l in lines)
                {
                    var values = l.Split(';');

                    if (values[0] == iden && values[1] == passwd)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur dans la lecture du fichier : " + ex);
                return false;
            }

            return false;
        }
    }
}

