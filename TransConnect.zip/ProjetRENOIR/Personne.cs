﻿using System;
namespace ProjetRENOIR
{
	public abstract class Personne
	{

		string numSS;
		string nom;
		string prenom;
		DateTime naissance;
		string adresse;
		string email;
		string telephone;

		public Personne(string numSS, string nom, string prenom, DateTime naissance, string adresse, string email, string telephone)
		{
			this.numSS = numSS;
			this.nom = nom;
			this.prenom = prenom;
			this.naissance = naissance;
			this.adresse = adresse;
			this.email = email;
			this.telephone = telephone;
        }

        public string NumSS
        {
            get { return numSS; }
        }

        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }

        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }

        public string Adresse
        {
            get { return adresse; }
            set { adresse = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Telephone
        {
            get { return telephone; }
            set { telephone = value; }
        }

        public override string ToString()
        {
            return "\nIdentité : " + nom + " " + prenom;
        }
    }
}

