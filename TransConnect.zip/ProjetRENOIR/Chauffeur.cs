﻿using System;
namespace ProjetRENOIR
{
	public class Chauffeur : Salarie
	{
		bool disponible;
        List<DateTime> historique;

        public Chauffeur(string numSS, string nom, string prenom, DateTime naissance, string adresse, string email, string telephone, DateTime dateEntree, string poste, double salaire, bool disponible) : base(numSS, nom, prenom, naissance, adresse, email, telephone, dateEntree, poste, salaire)
        {
            this.disponible = disponible;
            this.historique = new List<DateTime>();
        }

        public bool Disponible
        {
            get { return disponible; }
            set { disponible = value; }
        }

        public bool PeutEffectuerLivraison()
        {
            if (!disponible) return false;

            if (historique.Contains(DateTime.Today)) return false;

            return true;
        }

        public void EffectuerLivraison()
        {
            historique.Add(DateTime.Today);
            this.Disponible = false;
        }
    }
}

