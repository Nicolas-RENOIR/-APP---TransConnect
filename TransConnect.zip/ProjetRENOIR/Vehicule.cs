﻿using System;
namespace ProjetRENOIR
{
    public abstract class Vehicule
	{
		string immat;

		public Vehicule(string immat)
		{
			this.immat = immat;
		}

        public override string ToString()
        {
            return "Voiture immatriculée : " + immat;
        }
    }
}

