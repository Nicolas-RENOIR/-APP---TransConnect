﻿using System;
namespace ProjetRENOIR
{
	public interface IMajoration
	{
        double AppliquerMajoration(int prixBase, int km);
    }
}

