﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ProjetRENOIR
{
	public class Client : Personne, IComparable
	{
		List<Commande> historiqueCommande;
        bool reduc = false;

        public Client(string numSS, string nom, string prenom, DateTime naissance, string adresse, string email, string telephone, List<Commande> historiqueCommande, bool reduc) : base(numSS, nom, prenom, naissance, adresse, email, telephone)
        {
            this.historiqueCommande = historiqueCommande;
            this.reduc = reduc;
        }

        public Client(string numSS, string nom, string prenom, DateTime naissance, string adresse, string email, string telephone) : base(numSS, nom, prenom, naissance, adresse, email, telephone)
        {
        }

        public bool Reduc
        {
            get { return reduc; }
            set { reduc = value; }
        }

        public void Offrir()
        {
            reduc = true;
        }

        public void Payant()
        {
            reduc = false;
        }

        public List<Commande> HistoriqueCommande
        {
            get { return historiqueCommande; }
        }

        public int CompareTo(object c)
        {
            Client autreClient = c as Client;
            return this.Nom.CompareTo(autreClient.Nom);
        }

        public override string ToString()
        {
            string commandesInfo = "\n\n";
            foreach (Commande commande in historiqueCommande)
            {
                commandesInfo += "Date de livraison : " + commande.Date.ToString("dd-MM-yyyy") + "\nVille de départ : " + commande.AdresseDepart + "\nVille d'arrivée : " + commande.AdresseArrivee + "\nPrix : " + commande.Prix + "€\n\n";
            }

            return base.ToString() + commandesInfo;
        }
    }
}

