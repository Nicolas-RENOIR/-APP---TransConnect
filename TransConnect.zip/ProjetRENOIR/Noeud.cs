﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace ProjetRENOIR
{
    [Serializable]
    public class Noeud
	{
        Salarie salarie;
        List<Noeud> enfant;
        string nom;
        Dictionary<Noeud, int> voisins;

        public Noeud(Salarie salarie)
		{
            this.salarie = salarie;
            this.enfant = new List<Noeud>();
        }

        public Noeud(string nom)
        {
            this.nom = nom;
            voisins = new Dictionary<Noeud, int>();
        }

        public Noeud()
        {
        }

        public Salarie Salarie
        {
            get { return salarie; }
            set { salarie = value; }
        }

        public List<Noeud> Enfant
        {
            get { return enfant; }
            set { enfant = value; }
        }

        public void AjouterFils(Noeud n)
        {
            enfant.Add(n);
        }

        public void SupprimerFils(Noeud n)
        {
            enfant.Remove(n);
        }

        public bool EstFeuille()
        {
            if (enfant.Count == 0) return true;
            return false;
        }

        public void AjouterVoisin(Noeud n, int distance)
        {
            voisins.Add(n, distance);
        }

        public string Nom()
        {
            return nom;
        }

        public Dictionary<Noeud, int> Voisins()
        {
            return voisins;
        }
    }
}

