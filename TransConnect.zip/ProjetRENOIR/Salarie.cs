﻿using System;
namespace ProjetRENOIR
{
    [Serializable]
    public class Salarie : Personne
	{
		DateTime dateEntree;
		string poste;
		double salaire;

        public Salarie(string numSS, string nom, string prenom, DateTime naissance, string adresse, string email, string telephone, DateTime dateEntree, string poste, double salaire) : base (numSS, nom, prenom, naissance, adresse, email, telephone)
		{
			this.dateEntree = dateEntree;
			this.poste = poste;
			this.salaire = salaire;
        }

        public Salarie() : base("", "", "", DateTime.MinValue, "", "", "")
        {
            this.dateEntree = DateTime.MinValue;
            this.Poste = "";
            this.Salaire = 0;
        }

        public string Poste
        {
            get { return poste; }
            set { poste = value; }
        }

        public double Salaire
        {
            get { return salaire; }
            set { salaire = value; }
        }

        public override string ToString()
        {
            return base.ToString() + "Date d'entrée : " + dateEntree.ToString() + "Poste : " + poste + " Salaire : " + salaire;
        }
    }
}

