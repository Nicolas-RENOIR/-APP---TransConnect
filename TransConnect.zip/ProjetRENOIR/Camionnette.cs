﻿using System;
namespace ProjetRENOIR
{
	public class Camionnette : Vehicule, IMajoration
    {
		string usage;

		public Camionnette(string immat, string usage) : base(immat)
		{
			this.usage = usage;
		}

        public override string ToString()
        {
            return base.ToString() + " Usage " + usage;
        }

        public double AppliquerMajoration(int prixBase, int km)
        {
            return prixBase * 1.15 + (km / 100.0);
        }
    }
}

