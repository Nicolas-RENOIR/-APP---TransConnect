﻿using System;
namespace ProjetRENOIR
{
	public class CamionBenne : Camion, IMajoration
	{
		int nbBenne;
		bool grue;

		public CamionBenne(string immat, int volume, string matieres, int nbBenne, bool grue) : base(immat, volume, matieres)
        {
			this.nbBenne = nbBenne;
			this.grue = grue;
		}

        public override string ToString()
        {
            return base.ToString() + " Nombre de bennes : " + nbBenne + "A une grue : " + grue;
        }

        public double AppliquerMajoration(int prixBase, int km)
        {
            return prixBase * 1.60 + (km / 100);
        }
    }
}

