﻿using System;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ProjetRENOIR
{
    public delegate int Comparer<T>(T x, T y);

    public class NoeudChainee<T>
	{
        T donnee;
        NoeudChainee<T> suivant;

        public NoeudChainee(T x)
        {
            suivant = null;
            donnee = x;
        }

        public T Donnee
        {
            get { return donnee; }
            set { donnee = value; }
        }

        public NoeudChainee<T> Suivant
		{
            get { return suivant; }
            set { suivant = value; }
        }
	}
}

