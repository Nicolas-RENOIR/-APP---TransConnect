﻿using System;
namespace ProjetRENOIR
{
	public class Commande : IComparable
	{
		Client client;
		string adresseDepart;
		string adresseArrivee;
		double prix;
        Vehicule vehicule;
		Chauffeur chauffeur;
		DateTime date;
        int id;

		public Commande(Client client, string adresseDepart, string adresseArrivee, Vehicule vehicule, double prix, Chauffeur chauffeur, DateTime date, int id)
		{
			this.client = client;
            if (client.Reduc == true)
            {
                prix = 0;
                client.Payant();
            }
            else this.prix = prix;
            this.adresseDepart = adresseDepart;
			this.adresseArrivee = adresseArrivee;
            this.vehicule = vehicule;
            this.chauffeur = chauffeur;
			this.date = date;
            this.id = id;
            client.HistoriqueCommande.Add(this);
        }

        public string Prenom
        {
            get { return client.Prenom; }
        }

        public string Chauffeur
        {
            get { return chauffeur.Prenom; }
        }

        public string NumSS
        {
            get { return client.NumSS; }
        }

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        public int Id
        {
            get { return id; }
        }

        public string AdresseDepart
        {
            get { return adresseDepart; }
        }

        public string AdresseArrivee
        {
            get { return adresseArrivee; }
            set { adresseArrivee = value; }
        }

        public double Prix
        {
            get { return prix; }
            set { prix = value; }
        }

        public int CompareTo(object c)
        {
            Commande autreCommande = c as Commande;
            return this.Prix.CompareTo(autreCommande.Prix);
        }

        public override string ToString()
        {
            return "Commande de : " + client.Nom + " " + client.Prenom + "\nVille de départ : " + adresseDepart + "\nVille d'arrivée : " + adresseArrivee + "\nPrix : " + prix.ToString() + "€\nChauffeur : " + chauffeur.Nom + " " + chauffeur.Prenom + "\nDate : " + date.ToString("dd-MM-yyyy") + "\nNuméro de commande : " + id + "\n";
        }

        public string ToStringFile()
        {
            return "Prix : " + prix.ToString() + "€ - Chauffeur : " + chauffeur.Prenom + " - Date : " + date.ToString("dd-MM-yyyy") + "\n";
        }
    }
}

